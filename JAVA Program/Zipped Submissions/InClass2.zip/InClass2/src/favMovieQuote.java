// Thomas Campbell, 8-18-2024, in class 2 ch1
public class favMovieQuote {

	public static void main(String[] args) {
		System.out.println("Movie name: Rush Hour");
		System.out.println("Quote: This is the LAPD. We're the most hated cops in all the free world. My own mama's ashamed of me. She tells everybody I'm a drug dealer.");
		System.out.println("Year produced: 1998");
		System.out.println("Character: Detective James Carter, LAPD");
	}

}
