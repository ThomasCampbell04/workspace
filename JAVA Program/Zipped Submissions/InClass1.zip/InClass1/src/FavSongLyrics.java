// Thomas Campbell, 8-18-2024, in class 1 ch1
public class FavSongLyrics {

	public static void main(String[] args) {
		System.out.println("Turn your magic on, umi she'd say");
		System.out.println("Everything you want's a dream away");
		System.out.println("We are legends, every day");
		System.out.println("That's what she told him");

	}

}
